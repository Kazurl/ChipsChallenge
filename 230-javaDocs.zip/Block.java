/**
 * The {@code Block} class represents a block entity in a game, extending the functionality
 * of the {@link Actor} class. It includes properties such as whether it is on ice, collision status,
 * and its specific location on the game grid.
 */
public class Block extends Actor {

    private boolean onIce;
    private boolean collision = true;
    private int locationX;
    private int locationY;

    /**
     * Slides the block on ice, updating its position based on the provided tile.
     *
     * @param tile The {@link Tile} representing the ice tile on which the block is sliding.
     */
    public void slideOnIce(Tile tile){
        // To be implemented
    }

    /**
     * Interacts with a player, defining the behavior when a player interacts with this block.
     *
     * @param player The {@link Player} interacting with the block.
     */
    public void interactPlayer(Player player){
        // To be implemented
    }
}
