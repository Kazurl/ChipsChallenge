/**
 * The {@code Buttons} class represents a button tile in a game, extending the functionality
 * of the {@link Tile} class. It includes properties and methods specific to button behavior.
 */
public class Buttons extends Tile {

    // Attribute:
    private boolean buttonState;

    // Constructors:

    /**
     * Constructs a new {@code Buttons} instance with the specified coordinates.
     *
     * @param x The X-coordinate of the button tile.
     * @param y The Y-coordinate of the button tile.
     */
    public Buttons(int x, int y) {
        super(true, true);
        this.buttonState = false; // Set initial state as false
    }

    /**
     * Constructs a new {@code Buttons} instance with the specified coordinates and a connected trap.
     *
     * @param x              The X-coordinate of the button tile.
     * @param y              The Y-coordinate of the button tile.
     * @param connectedTrap The {@link Trap} connected to the button.
     */
    public Buttons(int x, int y, Trap connectedTrap) {
        super(true, true);
        this.buttonState = false; // Set initial state as false
    }

    // Getter:

    /**
     * Gets the current state of the button.
     *
     * @return {@code true} if the button is pressed, {@code false} otherwise.
     */
    public boolean getButtonState() {
        return buttonState;
    }

    // Setter:

    /**
     * Sets the state of the button.
     *
     * @param buttonState {@code true} to set the button as pressed, {@code false} to set it as released.
     */
    public void setButtonState(boolean buttonState) {
        this.buttonState = buttonState;
    }

    // Interacting Methods:

    /**
     * Interacts with a player, pressing the button when the player or mob interacts with it.
     *
     * @param player The {@link Player} interacting with the button.
     * @param mob The {@link Mob} interacting with the button.
     */
    public void interactPlayer(Player player) {
    }

    public void interactMob(Mob mob) {
        // When interacted with mob or player, button is pressed.
    }

    /**
     * Interacts with a block, pressing the button when the block interacts with it.
     *
     * @param block The {@link Block} interacting with the button.
     */
    public void interactBlock(Block block) {
        // When interacted with block, button is pressed.
    }

    // Other methods:

    /**
     * Presses the button, setting its state to true.
     */
    public void press() {
        buttonState = true;
    }

    /**
     * Releases the button, setting its state to false.
     */
    public void release() {
        buttonState = false;
    }
}
