import javafx.scene.input.KeyCode;

/**
 * The {@code Actor} class represents a game actor with a location, movement properties, and direction.
 * It can be used as a base class for game entities that require position and movement functionality.
 */
public class Actor {

    private int actorLocationX;
    private int actorLocationY;
    private int ticksPerMove;
    private int lastMoveTick;
    private KeyCode direction;
    private int[][] map;

    /**
     * Constructs a new {@code Actor} with an initial location at (0, 0).
     */
    public Actor() {
        this.actorLocationX = 0;
        this.actorLocationY = 0;
    }

    /**
     * Gets the X-coordinate and Y-coordinate of the actor's current location.
     *
     * @return The X-coordinate and Y-coordinate of the actor's location.
     */
    public int getLocationX() {
        return actorLocationX;
    }

    public int getLocationY() {
        return actorLocationY;
    }

    /**
     * Sets the location of the actor to the specified coordinates.
     *
     * @param x The X-coordinate to set for the actor's location.
     * @param y The Y-coordinate to set for the actor's location.
     */
    public void setLocation(int x, int y) {
        actorLocationX = x;
        actorLocationY = y;
    }

    /**
     * Gets the current direction of the actor's movement.
     *
     * @return The {@code KeyCode} representing the current direction.
     */
    public KeyCode getDirection() {
        return direction;
    }

    /**
     * Sets the direction of the actor's movement.
     *
     * @param dir The {@code KeyCode} representing the new direction.
     */
    public void setDirection(KeyCode dir) {
        direction = dir;
    }

    /**
     * Updates the actor's state based on its current properties.
     * The method is intended to be overridden in subclasses to provide specific update logic.
     */
    public void update() {
        // Need to update this method
        // Idea will be that direction will be randomly selected using RNG,
        // then set the next tile of the actor to be 1 tile in that chosen direction
    }

    /*
    // From Freddie: Should actor be trying to print the map?
    // To print out the state of the map
    public String toString() {
        String str = "";
        for (int[] row : map) {
            str = Arrays.toString(row) + "\n";
        }
        return str;
    }
    */
}
