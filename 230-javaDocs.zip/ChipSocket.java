/**
 * The {@code ChipSocket} class represents a chip socket tile in a game, extending the functionality
 * of the {@link Tile} class. It includes properties and methods specific to chip socket behavior.
 */
public class ChipSocket extends Tile {

    // Attribute:
    private int chipAmountNeeded;

    // Constructor:

    /**
     * Constructs a new {@code ChipSocket} instance with the specified amount of chips needed.
     *
     * @param chips The number of chips needed to unlock the chip socket.
     */
    public ChipSocket(int chips) {
        super(false, false);
        this.chipAmountNeeded = chips;
    }

    // Getter:

    /**
     * Gets the amount of chips needed to unlock the chip socket.
     *
     * @return The number of chips needed to unlock the chip socket.
     */
    public int getChipAmountNeeded() {
        return chipAmountNeeded;
    }

    // Unlock method:

    /**
     * Unlocks the chip socket, indicating that the required amount of chips has been inserted.
     */
    public void Unlock() {
        // To be implemented
    }
}
