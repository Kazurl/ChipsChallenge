/**
 * The Ice class represents a type of tile in a game that can be skated on.
 * It extends the Tile class and includes information about its corner type.
 */
public class Ice extends Tile {

    /**
     * Enumeration representing the corner types of the Ice tile.
     * Corner types include NONE, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, and BOTTOM_RIGHT.
     */
    public enum CornerType {
        NONE,
        TOP_LEFT,
        TOP_RIGHT,
        BOTTOM_LEFT,
        BOTTOM_RIGHT
    }

    /** The corner type of the Ice tile. */
    private CornerType cornerType;

    /** The X-coordinate and Y-coordinate of the Ice tile's location. */
    private int locationX;

    private int locationY;

    /**
     * Constructor for the Ice tile.
     *
     * @param x The X-coordinate of the Ice tile's location.
     * @param y The Y-coordinate of the Ice tile's location.
     * @param cornerType The corner type of the Ice tile.
     */
    public Ice(int x, int y, CornerType cornerType) {
        super(true, true);
        this.locationX = x;
        this.locationY = y;
        this.cornerType = cornerType;
    }

    /**
     * Gets the corner type of the Ice tile.
     *
     * @return The corner type of the Ice tile.
     */
    public CornerType getCornerType() {
        return cornerType;
    }
}
