/**
 * The {@code Bug} class represents a bug entity in a game, extending the functionality
 * of the {@link Mob} class. It includes properties and methods specific to bug behavior.
 */
public class Bug extends Mob {

    private boolean followLeft;

    /**
     * Constructs a new {@code Bug} with default properties.
     */
    public Bug() {
        // To be implemented
    }

    /**
     * Constructs a new {@code Bug} with the specified starting tile.
     *
     * @param tile The initial {@link Tile} for the bug.
     */
    public Bug(Tile tile) {
        super(tile);
    }

    /**
     * Sets the direction for the bug to follow.
     *
     * @param left {@code true} if the bug should follow left, {@code false} otherwise.
     */
    public void setFollow(boolean left) {
        this.followLeft = left;
    }

    /**
     * Gets the direction the bug is set to follow.
     *
     * @return {@code true} if the bug should follow left, {@code false} otherwise.
     */
    public boolean getFollow() {
        return this.followLeft;
    }
}
