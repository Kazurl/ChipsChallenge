import java.util.ArrayDeque;
import java.util.Queue;

/**
 * The Frog class represents a frog entity in a game, extending the Mob class.
 * It is capable of navigating a 2D map to find the shortest path to a specified destination.
 */
public class Frog extends Mob {

    /** Constant representing a traversed cell on the map. */
    final static int TRAVERSED = 2;

    /** Constant representing a path cell on the map. */
    final static int PATH = 3;

    /** 2D array representing the game map. */
    private int[][] map;

    /**
     * Default constructor for the Frog class.
     */
    public Frog() {}

    /**
     * Parameterized constructor for the Frog class.
     *
     * @param tile The initial tile on which the frog is placed.
     */
    public Frog(Tile tile) {
        super(tile);
    }

    /**
     * Checks for the shortest path from the frog's current position to a specified destination on the map.
     *
     * @param startx The starting X-coordinate on the map.
     * @param starty The starting Y-coordinate on the map.
     * @param playerx The destination X-coordinate on the map.
     * @param playery The destination Y-coordinate on the map.
     * @return True if a path to the destination exists, false otherwise.
     */
    private boolean checkShortest(int startx, int starty, int playerx, int playery) {
        Queue<int[]> Q = new ArrayDeque<>();
        Q.offer(new int[]{startx, starty});

        while (!Q.isEmpty()) {
            int[] curr = Q.poll();
            int row = curr[0];
            int col = curr[1];

            if (isEnd(row, col, playerx, playery)) {
                map[row][col] = PATH;
                return true;
            } else {
                map[row][col] = TRAVERSED;

                int[][] directions = {{-1,0}, {0,1}, {1,0}, {0, -1}};
                for (int[] dir : directions) {
                    int nextRow = row + dir[0];
                    int nextCol = col + dir[1];

                    if (isValid(nextRow, nextCol)) {
                        Q.offer(new int[]{nextRow, nextCol});
                        map[nextRow][nextCol] = TRAVERSED;
                    }
                }
            }
        }

        return false;
    }

    /**
     * Checks if the current position is the destination.
     *
     * @param row The current row on the map.
     * @param col The current column on the map.
     * @param playerx The destination X-coordinate on the map.
     * @param playery The destination Y-coordinate on the map.
     * @return True if the current position is the destination, false otherwise.
     */
    private boolean isEnd(int row, int col, int playerx, int playery) {
        return row == playerx && col == playery;
    }

    /**
     * Checks if the given position is valid for traversal.
     *
     * @param row The row to be checked.
     * @param col The column to be checked.
     * @return True if the position is valid, false otherwise.
     */
    private boolean isValid(int row, int col) {
        if (validHeight(row, map.length) && validWidth(col, map[0].length) && isAccessible(row, col) && !isTraversed(row, col)) {
            return true;
        }
        return false;
    }

    /**
     * Checks if the given position is accessible on the map.
     *
     * @param row The row to be checked.
     * @param col The column to be checked.
     * @return True if the position is accessible, false otherwise.
     */
    private boolean isAccessible(int row, int col) {
        return map[row][col] == 1;
    }

    /**
     * Checks if the given position has already been traversed.
     *
     * @param row The row to be checked.
     * @param col The column to be checked.
     * @return True if the position has been traversed, false otherwise.
     */
    private boolean isTraversed(int row, int col) {
        return map[row][col] == TRAVERSED;
    }

    /**
     * Checks if the given row is within the valid height range of the map.
     *
     * @param row The row to be checked.
     * @param height The height of the map.
     * @return True if the row is within the valid height range, false otherwise.
     */
    private boolean validHeight(int row, int height) {
        return row >= 0 && row < height;
    }

    /**
     * Checks if the given column is within the valid width range of the map.
     *
     * @param col The column to be checked.
     * @param width The width of the map.
     * @return True if the column is within the valid width range, false otherwise.
     */
    private boolean validWidth(int col, int width) {
        return col >= 0 && col < width;
    }
}
