/**
 * The Item class represents an item in a game, characterized by its location on the game map.
 */
public class Item {

    /** The X-coordinate and Y-coordinate of the item's location. */
    public int itemLocationX;
    public int itemLocationY;

    /**
     * Constructor for the Item class, specifying its initial location.
     *
     * @param itemLocationX The initial X-coordinate of the item.
     * @param itemLocationY The initial Y-coordinate of the item.
     */
    public Item(int itemLocationX, int itemLocationY) {
        this.itemLocationX = itemLocationX;
        this.itemLocationY = itemLocationY;
    }

    /**
     * Sets the X-coordinate and Y-coordinate of the item's location.
     *
     * @param locationX The new X-coordinate of the item.
     * @param locationY The new Y-coordinate of the item.
     */
    public void setX(int locationX) {
        this.itemLocationX = locationX;
    }

    public void setY(int locationY) {
        this.itemLocationY = locationY;
    }

    /**
     * Gets the X-coordinate and Y-coordinate of the item's location.
     *
     * @return The X-coordinate of the item.
     * @return The Y-coordinate of the item.
     */
    public int getX() {
        return this.itemLocationX;
    }

    public int getY() {
        return this.itemLocationY;
    }
}
