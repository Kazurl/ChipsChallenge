/**
 * The {@code Exit} class represents an exit tile in a game, extending the functionality
 * of the {@link Tile} class. It includes properties and methods specific to exit behavior.
 */
public class Exit extends Tile {

    // Coordinates of the exit
    private int exitX;
    private int exitY;

    /**
     * Constructs a new {@code Exit} instance with the specified coordinates.
     *
     * @param x The X-coordinate of the exit tile.
     * @param y The Y-coordinate of the exit tile.
     */
    public Exit(int x, int y) {
        super(true, false);
        this.exitX = x;
        this.exitY = y;
    }

    // Getters:

    /**
     * Gets the X-coordinate and Y-coordinate of the exit tile.
     *
     * @return The X-coordinate of the exit tile.
     * @return The Y-coordinate of the exit tile.
     */
    public int getExitX() {
        return exitX;
    }

    public int getExitY() {
        return exitY;
    }

    // Setters:

    /**
     * Sets the X-coordinate and the Y-coordiante of the exit tile.
     *
     * @param x The new X-coordinate for the exit tile.
     * @param y The new Y-coordinate for the exit tile.
     */
    public void setExitX(int x) {
        this.exitX = x;
    }

    public void setExitY(int y) {
        this.exitY = y;
    }

    /**
     * Checks if the player is on the exit tile.
     *
     * @param player The {@link Player} to check for.
     * @return {@code true} if the player is on the exit tile, {@code false} otherwise.
     */
    public boolean isPlayerOnExit(Player player) {
        return player.getX() == getExitX() && player.getY() == getExitY();
    }

    /*
    // Currently commented out, as the logic for winning the level is not specified
    public boolean isLevelWon(Player player, int time) {
       // To be implemented based on specific game logic
    }
    */
}
