/**
 * The abstract class Interactables represents entities that can interact with both players and mobs in a game.
 * Classes extending this abstract class must implement specific interactions with mobs and players.
 */
public abstract class Interactables {

    /** The player and mob instance associated with the interactable entity. */
    protected Player player;
    protected Mob mob;

    /**
     * Abstract method to define the interaction with a mob and player.
     * Implementations should specify the behavior when interacting with mobs and players.
     *
     * @param mob The mob to interact with.
     * @param player The player to interact with.
     */
    public abstract void interactMob(Mob mob);
    public abstract void interactPlayer(Player player);
}
