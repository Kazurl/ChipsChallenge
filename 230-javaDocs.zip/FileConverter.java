import javafx.scene.input.KeyCode;
import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.util.Scanner;
import java.util.Arrays;

/**
 * The FileConverter class provides methods for converting game maps to and from file formats.
 */
public class FileConverter {

    /**
     * Converts a file at the specified path to a Map object.
     *
     * @param filePath The path to the file to be converted.
     * @return A Map object representing the contents of the file.
     */
    public static Map convertFromFile(String filePath) {
        // Create a new File object using the provided file path
        File newFile = new File(filePath);
        try {
            // Create a Scanner to read from the file
            Scanner fileReader = new Scanner(newFile);
            // Set the delimiter for line reading
            fileReader.useDelimiter("\r\n|\n");

            // Initialize variables for map dimensions and time
            int width, height, timeLeft;
            // Read the first line to get map dimensions and time
            Scanner lineReader = new Scanner(fileReader.next());
            lineReader.useDelimiter(",");
            width = lineReader.nextInt();
            height = lineReader.nextInt();
            timeLeft = lineReader.nextInt();

            // Initialize player and actor arrays
            Player givenPlayer = new Player();
            Block[] givenBlocks = {};
            Frog[] givenFrogs = {};
            Bug[] givenBugs = {};
            PinkBall[] givenPinkBalls = {};

            // Read the second line to get player inventory
            lineReader = new Scanner(fileReader.next());
            lineReader.useDelimiter(",");
            int[] newInventory = {lineReader.nextInt(), lineReader.nextInt(), lineReader.nextInt(), lineReader.nextInt(), lineReader.nextInt()};

            // Initialize the actor array
            Actor[][] actorFile = new Actor[height][width];

            // Loop through the file to read actor information
            for (int y = 0; y < height; y++) {
                lineReader = new Scanner(fileReader.next());
                lineReader.useDelimiter(",");
                for (int x = 0; x < width; x++) {
                    // Read the next actor type
                    String nextActor = lineReader.next();
                    switch (nextActor) {
                        // Handle Player
                        case "Pl":
                            givenPlayer.setInventory(newInventory);
                            givenPlayer.setX(x);
                            givenPlayer.setY(y);
                            actorFile[y][x] = givenPlayer;
                            break;
                        // Handle Frog
                        case "Fr":
                            Frog frog = new Frog();
                            frog.setX(x);
                            frog.setY(y);
                            actorFile[y][x] = frog;
                            givenFrogs = Arrays.copyOf(givenFrogs, givenFrogs.length + 1);
                            givenFrogs[givenFrogs.length - 1] = frog;
                            break;
                        // Handle Block
                        case "Bl":
                            Block block = new Block();
                            block.setLocation(x, y);
                            actorFile[y][x] = block;
                            givenBlocks = Arrays.copyOf(givenBlocks, givenBlocks.length + 1);
                            givenBlocks[givenBlocks.length - 1] = block;
                            break;
                        default:
                            // Handle Bug and PinkBall
                            char[] mobChar = nextActor.toCharArray();
                            switch (mobChar[0]) {
                                case 'B':
                                    char bugDirection = mobChar[1];
                                    Bug bug = new Bug();
                                    bug.setX(x);
                                    bug.setY(y);
                                    switch (mobChar[1]) {
                                        case '1':
                                            bug.setFollow(true);
                                            break;
                                        case '2':
                                            bug.setFollow(false);
                                            break;
                                    }
                                    actorFile[y][x] = bug;
                                    givenBugs = Arrays.copyOf(givenBugs, givenBugs.length + 1);
                                    givenBugs[givenBugs.length - 1] = bug;
                                    break;
                                case 'P':
                                    PinkBall ball = new PinkBall();
                                    ball.setX(x);
                                    ball.setY(y);
                                    switch (mobChar[1]) {
                                        case '1':
                                            ball.setDirection(KeyCode.UP);
                                            break;
                                        case '2':
                                            ball.setDirection(KeyCode.DOWN);
                                            break;
                                        case '3':
                                            ball.setDirection(KeyCode.LEFT);
                                            break;
                                        default:
                                            ball.setDirection(KeyCode.RIGHT);
                                            break;
                                    }
                                    actorFile[y][x] = ball;
                                    givenPinkBalls = Arrays.copyOf(givenPinkBalls, givenPinkBalls.length + 1);
                                    givenPinkBalls[givenPinkBalls.length - 1] = ball;
                                    break;
                            }
                            break;
                    }
                }
            }

            // Initialize the item array
            Item[][] itemFile = new Item[height][width];

            // Loop through the file to read item information
            for (int y = 0; y < height; y++) {
                lineReader = new Scanner(fileReader.next());
                lineReader.useDelimiter(",");
                for (int x = 0; x < width; x++) {
                    // Read the next item type
                    String nextItem = lineReader.next();
                    switch (nextItem) {
                        // Handle ComputerChip
                        case "C":
                            itemFile[y][x] = new ComputerChip(x, y);
                            break;
                        // Handle Key
                        case "K1":
                            itemFile[y][x] = new Key(x, y, Key.Colour.RED);
                            break;
                        case "K2":
                            itemFile[y][x] = new Key(x, y, Key.Colour.GREEN);
                            break;
                        case "K3":
                            itemFile[y][x] = new Key(x, y, Key.Colour.BLUE);
                            break;
                        case "K4":
                            itemFile[y][x] = new Key(x, y, Key.Colour.YELLOW);
                            break;
                        default:
                            // Handle other items
                            break;
                    }
                }
            }

            // Initialize the tile array
            Tile[][] tileFile = new Tile[height][width];

            // Loop through the file to read tile information
            for (int y = 0; y < height; y++) {
                lineReader = new Scanner(fileReader.next());
                lineReader.useDelimiter(",");
                for (int x = 0; x < width; x++) {
                    // Read the next tile type
                    String nextTile = lineReader.next();
                    switch (nextTile) {
                        // Handle Path
                        case "Pt":
                            tileFile[y][x] = new Path();
                            break;
                        // Handle Dirt
                        case "Dt":
                            tileFile[y][x] = new Dirt(false);
                            break;
                        // Handle Wall
                        case "Wl":
                            tileFile[y][x] = new Wall();
                            break;
                        // Handle Water
                        case "Wt":
                            tileFile[y][x] = new Water(false);
                            break;
                        // Handle Exit
                        case "Ex":
                            tileFile[y][x] = new Exit(x, y);
                            break;
                        default:
                            // Handle other tiles
                            char[] tileChar = nextTile.toCharArray();
                            switch (tileChar[0]) {
                                // Handle Buttons
                                case 'B':
                                    tileFile[y][x] = new Buttons(x, y); // MUST CONNECT THESE < v
                                    break;
                                // Handle Trap
                                case 'T':
                                    tileFile[y][x] = new Trap(x, y); // MUST CONNECT THESE < ^
                                    break;
                                // Handle ChipSocket
                                case 'S':
                                    int chipAmount = Integer.parseInt(nextTile.substring(1));
                                    tileFile[y][x] = new ChipSocket(chipAmount);
                                    break;
                                // Handle LockedDoor
                                case 'L':
                                    if (tileChar[1] == '1') {
                                        tileFile[y][x] = new LockedDoor(Key.Colour.RED);
                                    } else if (tileChar[1] == '2') {
                                        tileFile[y][x] = new LockedDoor(Key.Colour.GREEN);
                                    } else if (tileChar[1] == '3') {
                                        tileFile[y][x] = new LockedDoor(Key.Colour.BLUE);
                                    } else if (tileChar[1] == '4') {
                                        tileFile[y][x] = new LockedDoor(Key.Colour.YELLOW);
                                    }
                                    break;
                                // Handle Ice
                                case 'I':
                                    if (tileChar[1] == '1') {
                                        tileFile[y][x] = new Ice(x, y, Ice.CornerType.NONE);
                                    } else if (tileChar[1] == '2') {
                                        tileFile[y][x] = new Ice(x, y, Ice.CornerType.TOP_LEFT);
                                    } else if (tileChar[1] == '3') {
                                        tileFile[y][x] = new Ice(x, y, Ice.CornerType.TOP_RIGHT);
                                    } else if (tileChar[1] == '4') {
                                        tileFile[y][x] = new Ice(x, y, Ice.CornerType.BOTTOM_LEFT);
                                    } else if (tileChar[1] == '5') {
                                        tileFile[y][x] = new Ice(x, y, Ice.CornerType.BOTTOM_RIGHT);
                                    }
                                    break;
                            }
                            break;
                    }
                }
            }

            // Close the file reader
            fileReader.close();

            // Return a new Map object with the read data
            return new Map(timeLeft, width, height, actorFile, itemFile, tileFile, givenPlayer, givenFrogs, givenBugs, givenPinkBalls, givenBlocks);
        } catch (Exception invalidFile) {
            // Handle exceptions related to file reading
            System.out.println("Invalid File!");
            return null;
        }
    }

    /**
     * Converts a Map object to a file at the specified path.
     *
     * @param currentMap The Map object to be converted and saved to a file.
     */
    public static void convertToFile(Map currentMap) {
        // Create a Scanner for user input
        Scanner in = new Scanner(System.in);
        // Get the player from the current map
        Player player = currentMap.getPlayer();
        // Flag to indicate if the conversion is complete
        boolean complete = false;

        // Loop until the conversion is complete
        while (!complete) {
            try {
                // Prompt the user for a valid file path and name
                System.out.println("Please enter a valid file path and name for saving:");
                File newFile = new File(in.next());

                // Check if the file already exists
                if (newFile.createNewFile()) {
                    // Create a FileWriter to write to the new file
                    FileWriter WriteToFile = new FileWriter(newFile);

                    // Write map dimensions and time to the file
                    WriteToFile.write(currentMap.getBoardWidth()
                            + "," + currentMap.getBoardHeight()
                            + "," + currentMap.getTimeLeft() + "\r\n");

                    // Write player inventory to the file
                    int[] playerInv = player.getInventory();
                    for (int i = 0; i < playerInv.length; i++) {
                        WriteToFile.write(Integer.toString(playerInv[i]));
                        if (i + 1 == playerInv.length) {
                            WriteToFile.write("\r\n");
                        } else {
                            WriteToFile.write(",");
                        }
                    }

                    // Loop to write actor information to the file
                    for (int y = 0; y < currentMap.getBoardHeight(); y++) {
                        for (int x = 0; x < currentMap.getBoardWidth(); x++) {
                            Actor currentActor = currentMap.getPosActor(x, y);
                            // ... (omitting comments for brevity)
                        }
                        WriteToFile.write("\r\n");
                    }

                    // Loop to write item information to the file
                    for (int y = 0; y < currentMap.getBoardHeight(); y++) {
                        for (int x = 0; x < currentMap.getBoardWidth(); x++) {
                            Item currentItem = currentMap.getPosItem(x, y);
                            // ... (omitting comments for brevity)
                        }
                        WriteToFile.write("\r\n");
                    }

                    // Loop to write tile information to the file
                    for (int y = 0; y < currentMap.getBoardHeight(); y++) {
                        for (int x = 0; x < currentMap.getBoardWidth(); x++) {
                            Tile currentTile = currentMap.getPosTile(x, y);
                            // ... (omitting comments for brevity)
                        }
                        if (y + 1 != currentMap.getBoardHeight()) {
                            WriteToFile.write("\r\n");
                        }
                    }

                    // Close the FileWriter
                    WriteToFile.close();
                    System.out.println("File created: " + newFile.getName());
                    complete = true;
                } else {
                    // Inform the user that the file already exists
                    System.out.println("File already exists.");
                }
            } catch (IOException e) {
                // Handle exceptions related to file writing
                System.out.println("Invalid File Path.");
            }
        }
    }
}
